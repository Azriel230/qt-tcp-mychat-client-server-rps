#include "mychatserver.h"
#include "ui_mychatserver.h"

#include <QAbstractButton>

MyChatServer::MyChatServer(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MyChatServer)
{
    ui->setupUi(this);
    m_nextBlockSize = 0;
    rpsFlag = false;
    rpsPlayers = 0;
}

MyChatServer::~MyChatServer()
{
    delete ui;
}

void MyChatServer::slotNewConnection()
{
    qDebug() << "Фиксирую новое соединение!";
    ui->m_listwdg_logs->addItem("New connection!");
    QTcpSocket* clientSocket = m_server->nextPendingConnection();
    int userIdSocket = clientSocket->socketDescriptor();
    ClientSocketMap[userIdSocket] = clientSocket;
    connect(ClientSocketMap[userIdSocket], SIGNAL(disconnected()), ClientSocketMap[userIdSocket], SLOT(deleteLater()));
    connect(ClientSocketMap[userIdSocket], SIGNAL(readyRead()), this,  SLOT(slotReadClient()));
    sendToClient(ClientSocketMap[userIdSocket], "Server Response: Connected!");
}

void MyChatServer::slotReadClient()
{
    QTcpSocket* clientSocket = (QTcpSocket*)sender();
    QDataStream inStream(clientSocket);
    inStream.setVersion(QDataStream::Qt_6_5);

    forever
    {
        if(!m_nextBlockSize)
        {
            if(clientSocket->bytesAvailable() < (int)sizeof(quint16))
            {
                break;
            }

            inStream >> m_nextBlockSize;
        }

        if(clientSocket->bytesAvailable() < m_nextBlockSize)
        {
            break;
        }

        QTime time;
        QString str;
        inStream >> time >> str;

        QString strMessage = time.toString() + " " + "Client has sent - " + str;
        ui->m_listwdg_logs->addItem(strMessage);

        m_nextBlockSize = 0;

        if (!(rpsFlag == true && (str == "/rock" || str == "/paper" || str == "/scissors")))
        {
            foreach (int i, ClientSocketMap.keys())
            {
                sendToClient(ClientSocketMap[i], "Server response: Recceived \"" + str + "\"");
            }
        }
        else
        {
            foreach (int i, ClientSocketMap.keys())
            {
                sendToClient(ClientSocketMap[i], "Противник сделал выбор!");
            }
        }

        if (rpsFlag == false && str == "/rpsGameStart")
        {
            rpsFlag = true;
            foreach (int i, ClientSocketMap.keys())
            {
                sendToClient(ClientSocketMap[i], "Начинается игра в Камень-Ножницы-Бумагу! Приготовьтесь к игре и напишите одну из трех команд:\n /rock | /paper | /scissors \n");
            }
        }
        else if (rpsFlag == true && (str == "/rock" || str == "/paper" || str == "/scissors"))
        {
            if(str == "/rock")
                rpsRockPlayers.push_back(clientSocket);
            else if (str == "/paper")
                rpsPaperPlayers.push_back(clientSocket);
            else
                rpsScissorsPlayers.push_back(clientSocket);
            rpsPlayers++;
        }

        if (rpsFlag == true && rpsPlayers == ClientSocketMap.size())
        {
            rpsFlag = false;
            if(rpsRockPlayers.isEmpty() && rpsPaperPlayers.isEmpty() && !rpsScissorsPlayers.isEmpty())
            {
                foreach (auto i, rpsScissorsPlayers)
                {
                    sendToClient(i, "Ничья! Все выбрали ножницы!");
                }
            }
            else if(rpsRockPlayers.isEmpty() && !rpsPaperPlayers.isEmpty() && rpsScissorsPlayers.isEmpty())
            {
                foreach (auto i, rpsPaperPlayers)
                {
                    sendToClient(i, "Ничья! Все выбрали бумагу!");
                }
            }
            else if(!rpsRockPlayers.isEmpty() && rpsPaperPlayers.isEmpty() && rpsScissorsPlayers.isEmpty())
            {
                foreach (auto i, rpsRockPlayers)
                {
                    sendToClient(i, "Ничья! Все выбрали камень!");
                }
            }
            else if(!rpsRockPlayers.isEmpty() && !rpsPaperPlayers.isEmpty() && rpsScissorsPlayers.isEmpty())
            {
                foreach (auto i, rpsRockPlayers)
                {
                    sendToClient(i, "Вы проиграли! Противник выбрал бумагу!");
                }
                foreach (auto i, rpsPaperPlayers)
                {
                    sendToClient(i, "Вы победили! Противник выбрал камень!");
                }
            }
            else if(!rpsRockPlayers.isEmpty() && rpsPaperPlayers.isEmpty() && !rpsScissorsPlayers.isEmpty())
            {
                foreach (auto i, rpsScissorsPlayers)
                {
                    sendToClient(i, "Вы проиграли! Противник выбрал камень!");
                }
                foreach (auto i, rpsRockPlayers)
                {
                    sendToClient(i, "Вы победили! Противник выбрал ножницы!");
                }
            }
            else if(rpsRockPlayers.isEmpty() && !rpsPaperPlayers.isEmpty() && !rpsScissorsPlayers.isEmpty())
            {
                foreach (auto i, rpsPaperPlayers)
                {
                    sendToClient(i, "Вы проиграли! Противник выбрал ножницы!");
                }
                foreach (auto i, rpsScissorsPlayers)
                {
                    sendToClient(i, "Вы победили! Противник выбрал бумагу!");
                }
            }
            else if(!rpsRockPlayers.isEmpty() && !rpsPaperPlayers.isEmpty() && !rpsScissorsPlayers.isEmpty())
            {
                foreach (auto i, ClientSocketMap.keys())
                {
                    sendToClient(ClientSocketMap[i], "Ничья! Были выбраны все типы: камень, ножницы, бумага!");
                }
            }
            rpsRockPlayers.clear();
            rpsPaperPlayers.clear();
            rpsScissorsPlayers.clear();
            rpsPlayers = 0;
        }
    }
}

void MyChatServer::sendToClient(QTcpSocket* socket, const QString& str)
{
    QByteArray arrayBlock;
    arrayBlock.clear();
    QDataStream outStream(&arrayBlock, QIODevice::WriteOnly);
    outStream.setVersion(QDataStream::Qt_6_5);
    outStream << quint16(0) << QTime::currentTime() << str;

    outStream.device()->seek(0);
    outStream << quint16(arrayBlock.size() - sizeof(quint16));

    socket->write(arrayBlock);

}

void MyChatServer::on_m_pb_stopStartServer_clicked()
{
    if(ui->m_pb_stopStartServer->text() == "Start Server")
    {
        m_server = new QTcpServer(this);

        if(!m_server->listen(QHostAddress::Any, ui->m_lndt_portServer->text().toUShort()))
        {
            QMessageBox::critical(0, "Server Error", "Unable to start the server:" + m_server->errorString());
            m_server->close();
            return;
        }
        else
        {
            qDebug() << m_server->isListening() << "Сервер в работе";
            ui->m_listwdg_logs->addItem("Server works!");
            ui->m_pb_stopStartServer->setText("Stop Server");
        }

        connect(m_server, SIGNAL(newConnection()), SLOT(slotNewConnection()));
    }
    else //if button text == "Stop Server"
    {
        foreach (int i, ClientSocketMap.keys())
        {
            QDataStream stream(ClientSocketMap[i]);
            stream << QDateTime::currentDateTime().toString() << "\n";
            ClientSocketMap[i]->close();
            ClientSocketMap.remove(i);
        }
        m_server->close();
        qDebug() << "Сервер все...";
        ui->m_listwdg_logs->addItem("Server was stoped!");
        ui->m_pb_stopStartServer->setText("Start Server");
    }
}

