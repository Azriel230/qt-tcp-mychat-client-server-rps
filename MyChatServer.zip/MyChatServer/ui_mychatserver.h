/********************************************************************************
** Form generated from reading UI file 'mychatserver.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MYCHATSERVER_H
#define UI_MYCHATSERVER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MyChatServer
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout;
    QListWidget *m_listwdg_logs;
    QHBoxLayout *horizontalLayout;
    QPushButton *m_pb_stopStartServer;
    QLineEdit *m_lndt_hostServer;
    QLineEdit *m_lndt_portServer;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MyChatServer)
    {
        if (MyChatServer->objectName().isEmpty())
            MyChatServer->setObjectName("MyChatServer");
        MyChatServer->resize(407, 400);
        MyChatServer->setMinimumSize(QSize(400, 400));
        centralwidget = new QWidget(MyChatServer);
        centralwidget->setObjectName("centralwidget");
        gridLayout = new QGridLayout(centralwidget);
        gridLayout->setObjectName("gridLayout");
        m_listwdg_logs = new QListWidget(centralwidget);
        new QListWidgetItem(m_listwdg_logs);
        m_listwdg_logs->setObjectName("m_listwdg_logs");

        gridLayout->addWidget(m_listwdg_logs, 0, 0, 1, 1);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName("horizontalLayout");
        m_pb_stopStartServer = new QPushButton(centralwidget);
        m_pb_stopStartServer->setObjectName("m_pb_stopStartServer");

        horizontalLayout->addWidget(m_pb_stopStartServer);

        m_lndt_hostServer = new QLineEdit(centralwidget);
        m_lndt_hostServer->setObjectName("m_lndt_hostServer");

        horizontalLayout->addWidget(m_lndt_hostServer);

        m_lndt_portServer = new QLineEdit(centralwidget);
        m_lndt_portServer->setObjectName("m_lndt_portServer");

        horizontalLayout->addWidget(m_lndt_portServer);


        gridLayout->addLayout(horizontalLayout, 1, 0, 1, 1);

        MyChatServer->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MyChatServer);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 407, 21));
        MyChatServer->setMenuBar(menubar);
        statusbar = new QStatusBar(MyChatServer);
        statusbar->setObjectName("statusbar");
        MyChatServer->setStatusBar(statusbar);

        retranslateUi(MyChatServer);

        QMetaObject::connectSlotsByName(MyChatServer);
    } // setupUi

    void retranslateUi(QMainWindow *MyChatServer)
    {
        MyChatServer->setWindowTitle(QCoreApplication::translate("MyChatServer", "MyChatServer", nullptr));

        const bool __sortingEnabled = m_listwdg_logs->isSortingEnabled();
        m_listwdg_logs->setSortingEnabled(false);
        QListWidgetItem *___qlistwidgetitem = m_listwdg_logs->item(0);
        ___qlistwidgetitem->setText(QCoreApplication::translate("MyChatServer", "Chat logs:", nullptr));
        m_listwdg_logs->setSortingEnabled(__sortingEnabled);

        m_pb_stopStartServer->setText(QCoreApplication::translate("MyChatServer", "Start Server", nullptr));
        m_lndt_hostServer->setText(QCoreApplication::translate("MyChatServer", "127.0.0.1", nullptr));
        m_lndt_portServer->setText(QCoreApplication::translate("MyChatServer", "2323", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MyChatServer: public Ui_MyChatServer {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MYCHATSERVER_H
