
#ifndef MYCHATSERVER_H
#define MYCHATSERVER_H

#include <QMainWindow>
#include <QtWidgets>
#include <QtNetwork/QTcpServer>
#include <QtNetwork/QTcpSocket>
#include <QMessageBox>
#include <QDebug>

class QTcpServer;
class QTcpSocket;

QT_BEGIN_NAMESPACE
namespace Ui { class MyChatServer; }
QT_END_NAMESPACE

class MyChatServer : public QMainWindow

{
    Q_OBJECT

public:
    MyChatServer(QWidget *parent = nullptr);
    ~MyChatServer();

public slots:
    void slotNewConnection();
    void slotReadClient   ();


private slots:
    void on_m_pb_stopStartServer_clicked();

private:
    Ui::MyChatServer *ui;

    QTcpServer* m_server;
    quint16 m_nextBlockSize;
    QMap<int, QTcpSocket*> ClientSocketMap;

    QList<QTcpSocket*> rpsRockPlayers;
    QList<QTcpSocket*> rpsPaperPlayers;
    QList<QTcpSocket*> rpsScissorsPlayers;

    int rpsPlayers;
    bool rpsFlag;

private:
    void sendToClient(QTcpSocket* socket, const QString& str);
};

#endif // MYCHATSERVER_H
