
#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include <QtNetwork/QAbstractSocket>
#include <QtNetwork/QTcpSocket>
#include <QMessageBox>

class QTcpSocket;

QT_BEGIN_NAMESPACE
namespace Ui { class Dialog; }
QT_END_NAMESPACE

class Dialog : public QDialog

{
    Q_OBJECT

public:
    Dialog(QWidget *parent = nullptr);
    ~Dialog();

private slots:
    void onSocketConnected();
    void onSocketDisconnected();
    void onSocketReadyToRead();
    void onSocketDisplayError(QAbstractSocket::SocketError socketError);

    void on_m_pb_sendMessage_clicked();
    void on_m_pb_connect_clicked();
    void on_m_pb_disconnect_clicked();

private:
    Ui::Dialog *ui;

    QTcpSocket *m_socket;
    quint16 m_nextBlockSize;
};

#endif // DIALOG_H
