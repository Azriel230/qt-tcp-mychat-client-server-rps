/********************************************************************************
** Form generated from reading UI file 'dialog.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOG_H
#define UI_DIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_Dialog
{
public:
    QGridLayout *gridLayout_2;
    QGridLayout *gridLayout;
    QVBoxLayout *m_vblayout_logInOut;
    QLineEdit *m_lnedit_hostServer;
    QLineEdit *m_lnedit_portServer;
    QFrame *line_2;
    QPushButton *m_pb_connect;
    QPushButton *m_pb_disconnect;
    QFrame *line;
    QLabel *label;
    QTextEdit *m_pte_message;
    QPushButton *m_pb_sendMessage;
    QListWidget *m_lstwgt_chatlog;

    void setupUi(QDialog *Dialog)
    {
        if (Dialog->objectName().isEmpty())
            Dialog->setObjectName("Dialog");
        Dialog->resize(783, 567);
        gridLayout_2 = new QGridLayout(Dialog);
        gridLayout_2->setObjectName("gridLayout_2");
        gridLayout = new QGridLayout();
        gridLayout->setObjectName("gridLayout");
        m_vblayout_logInOut = new QVBoxLayout();
        m_vblayout_logInOut->setObjectName("m_vblayout_logInOut");
        m_lnedit_hostServer = new QLineEdit(Dialog);
        m_lnedit_hostServer->setObjectName("m_lnedit_hostServer");

        m_vblayout_logInOut->addWidget(m_lnedit_hostServer);

        m_lnedit_portServer = new QLineEdit(Dialog);
        m_lnedit_portServer->setObjectName("m_lnedit_portServer");

        m_vblayout_logInOut->addWidget(m_lnedit_portServer);

        line_2 = new QFrame(Dialog);
        line_2->setObjectName("line_2");
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);

        m_vblayout_logInOut->addWidget(line_2);

        m_pb_connect = new QPushButton(Dialog);
        m_pb_connect->setObjectName("m_pb_connect");

        m_vblayout_logInOut->addWidget(m_pb_connect);

        m_pb_disconnect = new QPushButton(Dialog);
        m_pb_disconnect->setObjectName("m_pb_disconnect");

        m_vblayout_logInOut->addWidget(m_pb_disconnect);

        line = new QFrame(Dialog);
        line->setObjectName("line");
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        m_vblayout_logInOut->addWidget(line);

        label = new QLabel(Dialog);
        label->setObjectName("label");

        m_vblayout_logInOut->addWidget(label);

        m_pte_message = new QTextEdit(Dialog);
        m_pte_message->setObjectName("m_pte_message");

        m_vblayout_logInOut->addWidget(m_pte_message);

        m_pb_sendMessage = new QPushButton(Dialog);
        m_pb_sendMessage->setObjectName("m_pb_sendMessage");

        m_vblayout_logInOut->addWidget(m_pb_sendMessage);


        gridLayout->addLayout(m_vblayout_logInOut, 2, 2, 1, 1);

        m_lstwgt_chatlog = new QListWidget(Dialog);
        new QListWidgetItem(m_lstwgt_chatlog);
        new QListWidgetItem(m_lstwgt_chatlog);
        new QListWidgetItem(m_lstwgt_chatlog);
        new QListWidgetItem(m_lstwgt_chatlog);
        new QListWidgetItem(m_lstwgt_chatlog);
        m_lstwgt_chatlog->setObjectName("m_lstwgt_chatlog");

        gridLayout->addWidget(m_lstwgt_chatlog, 0, 1, 3, 1);


        gridLayout_2->addLayout(gridLayout, 0, 0, 1, 1);


        retranslateUi(Dialog);

        QMetaObject::connectSlotsByName(Dialog);
    } // setupUi

    void retranslateUi(QDialog *Dialog)
    {
        Dialog->setWindowTitle(QCoreApplication::translate("Dialog", "Dialog", nullptr));
        m_lnedit_hostServer->setText(QCoreApplication::translate("Dialog", "127.0.0.1", nullptr));
        m_lnedit_portServer->setText(QCoreApplication::translate("Dialog", "2323", nullptr));
        m_pb_connect->setText(QCoreApplication::translate("Dialog", "Connect", nullptr));
        m_pb_disconnect->setText(QCoreApplication::translate("Dialog", "Disconnect", nullptr));
        label->setText(QCoreApplication::translate("Dialog", "\320\236\320\272\320\275\320\276 \320\264\320\273\321\217 \321\201\320\276\320\276\320\261\321\211\320\265\320\275\320\270\320\271:", nullptr));
        m_pb_sendMessage->setText(QCoreApplication::translate("Dialog", "Send Message", nullptr));

        const bool __sortingEnabled = m_lstwgt_chatlog->isSortingEnabled();
        m_lstwgt_chatlog->setSortingEnabled(false);
        QListWidgetItem *___qlistwidgetitem = m_lstwgt_chatlog->item(0);
        ___qlistwidgetitem->setText(QCoreApplication::translate("Dialog", "\320\224\320\276\320\261\321\200\320\276 \320\277\320\276\320\266\320\260\320\273\320\276\320\262\320\260\321\202\321\214 \320\262 \320\247\320\260\321\202! ", nullptr));
        QListWidgetItem *___qlistwidgetitem1 = m_lstwgt_chatlog->item(1);
        ___qlistwidgetitem1->setText(QCoreApplication::translate("Dialog", "\320\222\321\213 \320\274\320\276\320\266\320\265\321\202\320\265 \320\276\320\261\321\211\320\260\321\202\321\214\321\201\321\217 \321\201 \320\264\321\200\321\203\320\263\320\270\320\274\320\270 \320\277\320\276\320\273\321\214\320\267\320\276\320\262\320\260\321\202\320\265\320\273\321\217\320\274\320\270 \320\270", nullptr));
        QListWidgetItem *___qlistwidgetitem2 = m_lstwgt_chatlog->item(2);
        ___qlistwidgetitem2->setText(QCoreApplication::translate("Dialog", "\321\201\321\213\320\263\321\200\320\260\321\202\321\214 \320\262 \321\203\320\262\320\273\320\265\320\272\320\260\321\202\320\265\320\273\321\214\320\275\320\265\320\271\321\210\321\203\321\216 \320\270\320\263\321\200\321\203 - \320\232\320\260\320\274\320\265\320\275\321\214-\320\235\320\276\320\266\320\275\320\270\321\206\321\213-\320\221\321\203\320\274\320\260\320\263\320\260!", nullptr));
        QListWidgetItem *___qlistwidgetitem3 = m_lstwgt_chatlog->item(3);
        ___qlistwidgetitem3->setText(QCoreApplication::translate("Dialog", "\320\247\321\202\320\276\320\261\321\213 \321\201\321\213\320\263\321\200\320\260\321\202\321\214, \320\275\320\260\320\277\320\270\321\210\320\270\321\202\320\265 /rpsGameStart", nullptr));
        QListWidgetItem *___qlistwidgetitem4 = m_lstwgt_chatlog->item(4);
        ___qlistwidgetitem4->setText(QCoreApplication::translate("Dialog", "----------------------------------------------------------------------", nullptr));
        m_lstwgt_chatlog->setSortingEnabled(__sortingEnabled);

    } // retranslateUi

};

namespace Ui {
    class Dialog: public Ui_Dialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOG_H
