#include "dialog.h"
#include "ui_dialog.h"
#include <QTime>
#include <QtWidgets>
#include <QTextEdit>
class QTcpSocket;

Dialog::Dialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Dialog)
{
    ui->setupUi(this);

    m_socket = new QTcpSocket();

    connect(m_socket, SIGNAL(readyRead()), this, SLOT(onSocketReadyToRead()));
    connect(m_socket, SIGNAL(connected()), this, SLOT(onSocketConnected()));
    connect(m_socket, SIGNAL(disconnected()), this, SLOT(onSocketDisconnected()));
    //connect(m_socket, SIGNAL(QAbstractSocket::error()), this, SLOT(onSocketDisplayError(QAbstractSocket::SocketError)));
    //connect(m_socket, SIGNAL(error(QAbstractSocket::SocketError)), this, SLOT(onSocketDisplayError(QAbstractSocket::SocketError)));
}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::onSocketConnected()
{
    ui->m_pb_connect->setEnabled(false);
    ui->m_pb_disconnect->setEnabled(true);
    ui->m_pb_sendMessage->setEnabled(true);
    m_nextBlockSize = 0;
}

void Dialog::onSocketDisconnected()
{
    ui->m_pb_connect->setEnabled(true);
    ui->m_pb_disconnect->setEnabled(false);
    ui->m_pb_sendMessage->setEnabled(false);
}

void Dialog::onSocketReadyToRead()
{
    QDataStream inStream(m_socket);
    inStream.setVersion(QDataStream::Qt_6_5);
    for(;;)
    {
        if(!m_nextBlockSize)
        {
            if(m_socket->bytesAvailable() < (int)sizeof(quint16))
            {
                break;
            }
            inStream >> m_nextBlockSize;
        }

        if (m_socket->bytesAvailable() < m_nextBlockSize)
        {
            break;
        }

        QTime time;
        QString str;
        inStream >> time >> str;

        ui->m_lstwgt_chatlog->addItem(time.toString() + " " + str);
        m_nextBlockSize = 0;
    }
}

void Dialog::onSocketDisplayError(QAbstractSocket::SocketError socketError)
{
    switch (socketError)
    {
    case QAbstractSocket::RemoteHostClosedError:
    {
        break;
    }
    case QAbstractSocket::HostNotFoundError:
    {
        QMessageBox::information(this, "Error", "The host was not found");
        break;
    }
    case QAbstractSocket::ConnectionRefusedError:
    {
        QMessageBox::information(this, "Error", "The connection was refused by the peer.");
        break;
    }
    default:
    {
        QMessageBox::information(this, "Error", "The following error occurred: "+m_socket->errorString());
    }
    }
}

void Dialog::on_m_pb_sendMessage_clicked()
{
    QByteArray arrayBlock;
    arrayBlock.clear();
    QDataStream outStream(&arrayBlock, QIODevice::WriteOnly);
    outStream.setVersion(QDataStream::Qt_6_5);
    outStream << quint16(0) << QTime::currentTime() << ui->m_pte_message->toPlainText();

    outStream.device()->seek(0);
    outStream << quint16(arrayBlock.size() - sizeof(quint16));

    m_socket->write(arrayBlock);
    ui->m_pte_message->setText("");
}

void Dialog::on_m_pb_connect_clicked()
{
    m_socket->connectToHost(ui->m_lnedit_hostServer->text(), ui->m_lnedit_portServer->text().toUShort());
}

void Dialog::on_m_pb_disconnect_clicked()
{
    m_socket->disconnectFromHost();
}
